package com.tejasweb.MyWebProject;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class loginValidate extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		try {

			String email = request.getParameter("email");
			String password = request.getParameter("password");

			Configuration cfg = new org.hibernate.cfg.Configuration().configure()
					.addAnnotatedClass(registration_detail.class);
			SessionFactory sf = cfg.buildSessionFactory();
			Session session = sf.openSession();

			String query = "from registration_detail where email=:email and password=:password";
			Query q = session.createQuery(query);
			q.setParameter("email", email);
			q.setParameter("password", password);
			registration_detail result = (registration_detail) q.uniqueResult();

			if (result != null) {
				out.print("Login Successful!!");
				response.sendRedirect("dashboard.jsp");
			} 
			else {
				out.print("Failure!!");
				response.sendRedirect("login.jsp");
			}

			out.close();

		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
