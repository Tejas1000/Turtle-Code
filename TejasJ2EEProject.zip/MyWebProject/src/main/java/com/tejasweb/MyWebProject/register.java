package com.tejasweb.MyWebProject;

import org.hibernate.Session;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class register {
public static int registerUser(registration_detail obj) {
		
		int result = 0;
		
		Configuration cfg = new org.hibernate.cfg.Configuration().configure().addAnnotatedClass(registration_detail.class);
		SessionFactory sf = cfg.buildSessionFactory();
		Session ssn = sf.openSession();
		Transaction tx = ssn.beginTransaction();

		ssn.save(obj);
			
		tx.commit();
		
		result = 1;
		
		return result;
		
//		if(i == 1) {
//			return i;
//		}
//		else {
//			return --i;			
//		}
		
	}
}
